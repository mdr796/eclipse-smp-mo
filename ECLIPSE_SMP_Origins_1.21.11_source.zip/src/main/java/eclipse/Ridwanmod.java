package eclipse;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Ridwanmod implements ModInitializer {
    public static final String MOD_ID = "ridwanmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> PASSIVE_REFRESH = new HashMap<>();
    private static final String[] ORIGINS = {"volt", "shade", "verdant", "ember"};
    private static final String[] ORIGIN_NAMES = {"VOLT", "SHADE", "VERDANT", "EMBER"};
    private static final String[][] POWERS = {
        {"Thunder Dash", "Lightning Strike", "Super Jump", "Electric Shock"},
        {"Shadow Blink", "Veil of Shadows", "Shadow Decoy", "Darkness Wave"},
        {"Nature Heal", "Vine Trap", "Thorn Strike", "Nature Shield"},
        {"Fireball", "Inferno Burst", "Flame Dash", "Fire Shield"}
    };
    private static final int[][] COOLDOWN_SECONDS = {
        {8, 12, 10, 9}, {10, 18, 16, 14}, {18, 12, 10, 18}, {12, 16, 10, 18}
    };

    private static final Identifier VOLT_SPEED = id("volt_speed");
    private static final Identifier SHADE_SPEED = id("shade_speed");
    private static final Identifier VERDANT_HEALTH = id("verdant_health");

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("origin")
                .executes(ctx -> showOrigin(ctx.getSource().getPlayerOrThrow()))
                .then(CommandManager.literal("list")
                    .executes(ctx -> listOrigins(ctx.getSource().getPlayerOrThrow())))
                .then(CommandManager.literal("info")
                    .executes(ctx -> showOriginInfo(ctx.getSource().getPlayerOrThrow())))
                .then(CommandManager.literal("choose")
                    .then(CommandManager.argument("origin", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            for (String origin : ORIGINS) builder.suggest(origin);
                            return builder.buildFuture();
                        })
                        .executes(ctx -> chooseOrigin(ctx.getSource().getPlayerOrThrow(),
                            StringArgumentType.getString(ctx, "origin")))))
                .then(CommandManager.literal("set")
                    .requires(source -> source.hasPermissionLevel(2))
                    .then(CommandManager.argument("player", net.minecraft.command.argument.EntityArgumentType.player())
                        .then(CommandManager.argument("origin", StringArgumentType.word())
                            .suggests((ctx, builder) -> {
                                for (String origin : ORIGINS) builder.suggest(origin);
                                return builder.buildFuture();
                            })
                            .executes(ctx -> adminSetOrigin(
                                ctx.getSource().getPlayerOrThrow(),
                                net.minecraft.command.argument.EntityArgumentType.getPlayer(ctx, "player"),
                                StringArgumentType.getString(ctx, "origin"))))))
                .then(CommandManager.literal("reset")
                    .requires(source -> source.hasPermissionLevel(2))
                    .then(CommandManager.argument("player", net.minecraft.command.argument.EntityArgumentType.player())
                        .executes(ctx -> adminResetOrigin(
                            ctx.getSource().getPlayerOrThrow(),
                            net.minecraft.command.argument.EntityArgumentType.getPlayer(ctx, "player")))))
            );

            dispatcher.register(CommandManager.literal("power")
                .then(CommandManager.literal("info")
                    .executes(ctx -> showPowerInfo(ctx.getSource().getPlayerOrThrow())))
                .then(CommandManager.argument("slot", IntegerArgumentType.integer(1, 4))
                    .executes(ctx -> usePower(ctx.getSource().getPlayerOrThrow(),
                        IntegerArgumentType.getInteger(ctx, "slot"))))
            );
        });

        ServerTickEvents.END_SERVER_TICK.register(Ridwanmod::tickPassives);
        LOGGER.info("ECLIPSE SMP Origins initialized.");
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    private static OriginState state(MinecraftServer server) {
        PersistentStateManager manager = server.getOverworld().getPersistentStateManager();
        return manager.getOrCreate(OriginState.TYPE, "ridwanmod_origins");
    }

    private static int originIndex(String origin) {
        for (int i = 0; i < ORIGINS.length; i++) {
            if (ORIGINS[i].equalsIgnoreCase(origin)) return i;
        }
        return -1;
    }

    private static String getOrigin(MinecraftServer server, UUID uuid) {
        return state(server).origins.get(uuid);
    }

    private static int showOrigin(ServerPlayerEntity player) {
        String origin = getOrigin(player.getServer(), player.getUuid());
        if (origin == null) {
            player.sendMessage(Text.literal("§eYou have not chosen an Origin. Use §f/origin choose <volt|shade|verdant|ember>§e."), false);
        } else {
            player.sendMessage(Text.literal("§bYour Origin: §f" + origin.toUpperCase() + "§b. Use §f/origin info §bfor details."), false);
        }
        return 1;
    }

    private static int listOrigins(ServerPlayerEntity player) {
        player.sendMessage(Text.literal("§6ECLIPSE SMP Origins: §eVOLT, SHADE, VERDANT, EMBER"), false);
        player.sendMessage(Text.literal("§7Choose one with /origin choose <origin>. Your choice is saved."), false);
        return 1;
    }

    private static int showOriginInfo(ServerPlayerEntity player) {
        String origin = getOrigin(player.getServer(), player.getUuid());
        if (origin == null) {
            player.sendMessage(Text.literal("§eChoose an Origin first: /origin choose volt"), false);
            return 1;
        }
        int i = originIndex(origin);
        player.sendMessage(Text.literal("§6=== " + ORIGIN_NAMES[i] + " ORIGIN ==="), false);
        player.sendMessage(Text.literal("§ePassive: §f" + passiveDescription(i)), false);
        for (int slot = 0; slot < 4; slot++) {
            player.sendMessage(Text.literal("§b/power " + (slot + 1) + " §f- " + POWERS[i][slot] +
                " §7(" + COOLDOWN_SECONDS[i][slot] + "s cooldown)"), false);
        }
        return 1;
    }

    private static String passiveDescription(int i) {
        return switch (i) {
            case 0 -> "+15% movement speed";
            case 1 -> "+5% movement speed and reduced fall damage";
            case 2 -> "+2 maximum health";
            default -> "Fire resistance";
        };
    }

    private static int chooseOrigin(ServerPlayerEntity player, String requested) {
        if (originIndex(requested) < 0) {
            player.sendMessage(Text.literal("§cUnknown Origin. Choose volt, shade, verdant, or ember."), false);
            return 0;
        }
        OriginState state = state(player.getServer());
        if (state.origins.containsKey(player.getUuid())) {
            player.sendMessage(Text.literal("§cYou already chose an Origin. Only an admin can reset it."), false);
            return 0;
        }
        state.origins.put(player.getUuid(), requested.toLowerCase());
        state.markDirty();
        applyPassive(player, requested.toLowerCase());
        player.sendMessage(Text.literal("§aOrigin chosen: §f" + requested.toUpperCase() + "§a! Use /origin info and /power info."), false);
        return 1;
    }

    private static int adminSetOrigin(ServerPlayerEntity admin, ServerPlayerEntity target, String requested) {
        if (originIndex(requested) < 0) {
            admin.sendMessage(Text.literal("§cUnknown Origin. Use volt, shade, verdant, or ember."), false);
            return 0;
        }
        removePassives(target);
        OriginState state = state(admin.getServer());
        state.origins.put(target.getUuid(), requested.toLowerCase());
        state.markDirty();
        applyPassive(target, requested.toLowerCase());
        admin.sendMessage(Text.literal("§aSet " + target.getName().getString() + "'s Origin to " + requested.toUpperCase() + "."), false);
        target.sendMessage(Text.literal("§eAn admin assigned your Origin: §f" + requested.toUpperCase()), false);
        return 1;
    }

    private static int adminResetOrigin(ServerPlayerEntity admin, ServerPlayerEntity target) {
        OriginState state = state(admin.getServer());
        state.origins.remove(target.getUuid());
        state.markDirty();
        removePassives(target);
        COOLDOWNS.remove(target.getUuid());
        admin.sendMessage(Text.literal("§aReset Origin for " + target.getName().getString() + "."), false);
        target.sendMessage(Text.literal("§eYour Origin was reset by an admin. Choose again with /origin choose <origin>."), false);
        return 1;
    }

    private static int showPowerInfo(ServerPlayerEntity player) {
        String origin = getOrigin(player.getServer(), player.getUuid());
        if (origin == null) {
            player.sendMessage(Text.literal("§eChoose an Origin first with /origin choose <origin>."), false);
            return 1;
        }
        int i = originIndex(origin);
        player.sendMessage(Text.literal("§6Your " + ORIGIN_NAMES[i] + " powers:"), false);
        for (int slot = 0; slot < 4; slot++) {
            player.sendMessage(Text.literal("§b/power " + (slot + 1) + " §f- " + POWERS[i][slot] +
                " §7(" + COOLDOWN_SECONDS[i][slot] + "s cooldown)"), false);
        }
        return 1;
    }

    private static int usePower(ServerPlayerEntity player, int slot) {
        String origin = getOrigin(player.getServer(), player.getUuid());
        if (origin == null) {
            player.sendMessage(Text.literal("§eChoose an Origin first: /origin choose <origin>."), false);
            return 0;
        }
        int index = originIndex(origin);
        String cooldownKey = origin + ":" + slot;
        long now = System.currentTimeMillis();
        long readyAt = COOLDOWNS.getOrDefault(player.getUuid(), Map.of()).getOrDefault(cooldownKey, 0L);
        if (now < readyAt) {
            player.sendMessage(Text.literal("§c" + POWERS[index][slot - 1] + " is on cooldown for " +
                Math.max(1, (readyAt - now + 999) / 1000) + "s."), true);
            return 0;
        }
        boolean used = activatePower(player, index, slot);
        if (used) {
            COOLDOWNS.computeIfAbsent(player.getUuid(), ignored -> new HashMap<>())
                .put(cooldownKey, now + COOLDOWN_SECONDS[index][slot - 1] * 1000L);
        }
        return used ? 1 : 0;
    }

    private static boolean activatePower(ServerPlayerEntity player, int origin, int slot) {
        ServerWorld world = player.getServerWorld();
        switch (origin) {
            case 0 -> {
                switch (slot) {
                    case 1 -> { // Thunder Dash
                        if (!dash(player, 5.0)) return failed(player, "No safe space to dash.");
                        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1, player.getZ(), 28, .6, .7, .6, .08);
                        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.PLAYERS, .5f, 1.5f);
                    }
                    case 2 -> { // Lightning Strike
                        LivingEntity target = targetInFront(player, 14, 0.72);
                        if (target == null) return failed(player, "Look at a nearby target.");
                        damage(player, target, 6.0f);
                        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + 1, target.getZ(), 35, .5, .8, .5, .1);
                        world.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, .5f, 1.7f);
                    }
                    case 3 -> {
                        player.setVelocity(player.getVelocity().x, 1.05, player.getVelocity().z);
                        player.velocityModified = true;
                        world.spawnParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(), 14, .4, .1, .4, .04);
                    }
                    case 4 -> {
                        int hits = affectNearby(player, 4.5, target -> {
                            damage(player, target, 3.0f);
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 1), player);
                            world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + .8, target.getZ(), 10, .3, .4, .3, .04);
                        });
                        if (hits == 0) return failed(player, "No enemy nearby.");
                    }
                }
            }
            case 1 -> {
                switch (slot) {
                    case 1 -> {
                        if (!dash(player, 7.0)) return failed(player, "No safe shadow-blink location.");
                        world.spawnParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1, player.getZ(), 22, .6, .7, .6, .03);
                    }
                    case 2 -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 100, 0, false, false, true));
                        world.spawnParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1, player.getZ(), 18, .5, .7, .5, .02);
                    }
                    case 3 -> {
                        // Documented alternative to a full skin-copying clone: a temporary smoke decoy effect.
                        world.spawnParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + .8, player.getZ(), 45, .8, .9, .8, .03);
                        world.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 35, .7, .8, .7, .2);
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 50, 1, false, false, true));
                    }
                    case 4 -> {
                        int hits = affectNearby(player, 5.0, target -> {
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0), player);
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 0), player);
                        });
                        if (hits == 0) return failed(player, "No enemy nearby.");
                        world.spawnParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1, player.getZ(), 40, 1.2, .7, 1.2, .02);
                    }
                }
            }
            case 2 -> {
                switch (slot) {
                    case 1 -> {
                        player.heal(5.0f);
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 0), player);
                        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1, player.getZ(), 18, .6, .7, .6, .05);
                    }
                    case 2 -> {
                        int hits = affectNearby(player, 4.5, target -> {
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 3), player);
                            world.spawnParticles(ParticleTypes.COMPOSTER, target.getX(), target.getY(), target.getZ(), 15, .5, .3, .5, .02);
                        });
                        if (hits == 0) return failed(player, "No enemy nearby.");
                    }
                    case 3 -> {
                        LivingEntity target = targetInFront(player, 10, 0.7);
                        if (target == null) return failed(player, "Look at a nearby target.");
                        damage(player, target, 5.0f);
                        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 35, 0), player);
                        world.spawnParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 1, target.getZ(), 16, .4, .6, .4, .08);
                    }
                    case 4 -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 0), player);
                        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1, player.getZ(), 24, .7, .7, .7, .03);
                    }
                }
            }
            case 3 -> {
                switch (slot) {
                    case 1 -> {
                        Vec3d direction = player.getRotationVec(1.0F).normalize().multiply(0.8);
                        SmallFireballEntity fireball = new SmallFireballEntity(world, player, direction);
                        fireball.setPosition(player.getX(), player.getEyeY() - .1, player.getZ());
                        world.spawnEntity(fireball);
                    }
                    case 2 -> {
                        int hits = affectNearby(player, 4.5, target -> {
                            damage(player, target, 4.0f);
                            target.setOnFireFor(2);
                            world.spawnParticles(ParticleTypes.FLAME, target.getX(), target.getY() + .7, target.getZ(), 16, .5, .5, .5, .03);
                        });
                        if (hits == 0) return failed(player, "No enemy nearby.");
                        world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + .5, player.getZ(), 28, 1.0, .4, 1.0, .03);
                    }
                    case 3 -> {
                        if (!dash(player, 5.0)) return failed(player, "No safe space to flame dash.");
                        world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + .5, player.getZ(), 24, .7, .3, .7, .03);
                    }
                    case 4 -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 160, 0), player);
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 0), player);
                        world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1, player.getZ(), 20, .6, .7, .6, .03);
                    }
                }
            }
        }
        player.sendMessage(Text.literal("§aActivated: §f" + POWERS[origin][slot - 1]), true);
        return true;
    }

    private interface EntityAction { void accept(LivingEntity target); }

    private static int affectNearby(ServerPlayerEntity player, double radius, EntityAction action) {
        int hits = 0;
        Box box = player.getBoundingBox().expand(radius);
        for (LivingEntity target : player.getServerWorld().getEntitiesByClass(
                LivingEntity.class, box, entity -> entity != player && entity.isAlive() && !entity.isSpectator())) {
            if (target instanceof ServerPlayerEntity && !player.getServerWorld().getGameRules().getBoolean(net.minecraft.world.GameRules.PVP)) {
                continue;
            }
            action.accept(target);
            hits++;
        }
        return hits;
    }

    private static LivingEntity targetInFront(ServerPlayerEntity player, double range, double minDot) {
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d eye = player.getEyePos();
        Box box = player.getBoundingBox().stretch(look.multiply(range)).expand(1.5);
        LivingEntity best = null;
        double bestDistance = range * range;
        for (LivingEntity target : player.getServerWorld().getEntitiesByClass(
                LivingEntity.class, box, entity -> entity != player && entity.isAlive() && !entity.isSpectator())) {
            if (target instanceof ServerPlayerEntity && !player.getServerWorld().getGameRules().getBoolean(net.minecraft.world.GameRules.PVP)) continue;
            Vec3d delta = target.getEyePos().subtract(eye);
            double distance = delta.lengthSquared();
            if (distance > bestDistance || distance == 0) continue;
            if (look.dotProduct(delta.normalize()) >= minDot) {
                best = target;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static void damage(ServerPlayerEntity player, LivingEntity target, float amount) {
        target.damage(player.getServerWorld(), player.getDamageSources().playerAttack(player), amount);
    }

    private static boolean dash(ServerPlayerEntity player, double distance) {
        Vec3d look = player.getRotationVec(1.0F).normalize();
        ServerWorld world = player.getServerWorld();
        for (double step = distance; step >= 1.0; step -= 0.5) {
            double x = player.getX() + look.x * step;
            double y = player.getY();
            double z = player.getZ() + look.z * step;
            if (world.isSpaceEmpty(player, player.getBoundingBox().offset(x - player.getX(), 0, z - player.getZ()))
                    && world.isSpaceEmpty(player, player.getBoundingBox().offset(x - player.getX(), 1, z - player.getZ()))) {
                player.requestTeleport(x, y, z);
                return true;
            }
        }
        return false;
    }

    private static boolean failed(ServerPlayerEntity player, String message) {
        player.sendMessage(Text.literal("§c" + message), true);
        return false;
    }

    private static void tickPassives(MinecraftServer server) {
        long now = server.getTicks();
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (now - PASSIVE_REFRESH.getOrDefault(player.getUuid(), 0L) < 40) continue;
            PASSIVE_REFRESH.put(player.getUuid(), now);
            String origin = getOrigin(server, player.getUuid());
            if (origin != null) applyPassive(player, origin);
        }
    }

    private static void applyPassive(ServerPlayerEntity player, String origin) {
        EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(VOLT_SPEED);
            speed.removeModifier(SHADE_SPEED);
            if (origin.equals("volt")) {
                speed.addPersistentModifier(new EntityAttributeModifier(VOLT_SPEED, 0.15, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
            } else if (origin.equals("shade")) {
                speed.addPersistentModifier(new EntityAttributeModifier(SHADE_SPEED, 0.05, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
            }
        }
        EntityAttributeInstance health = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (health != null) {
            health.removeModifier(VERDANT_HEALTH);
            if (origin.equals("verdant")) {
                health.addPersistentModifier(new EntityAttributeModifier(VERDANT_HEALTH, 4.0, EntityAttributeModifier.Operation.ADD_VALUE));
                if (player.getHealth() < player.getMaxHealth()) player.heal(0.01f);
            }
        }
        if (origin.equals("shade")) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 80, 0, false, false, true));
        } else if (origin.equals("ember")) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 80, 0, false, false, true));
        }
    }

    private static void removePassives(ServerPlayerEntity player) {
        EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(VOLT_SPEED);
            speed.removeModifier(SHADE_SPEED);
        }
        EntityAttributeInstance health = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (health != null) health.removeModifier(VERDANT_HEALTH);
        player.removeStatusEffect(StatusEffects.SLOW_FALLING);
        player.removeStatusEffect(StatusEffects.FIRE_RESISTANCE);
    }

    private static class OriginState extends PersistentState {
        private static final Type<OriginState> TYPE = new Type<>(
            OriginState::new,
            OriginState::fromNbt,
            DataFixTypes.SAVED_DATA_COMMAND_STORAGE
        );
        private final Map<UUID, String> origins = new HashMap<>();

        private static OriginState fromNbt(NbtCompound nbt, net.minecraft.registry.RegistryWrapper.WrapperLookup registries) {
            OriginState state = new OriginState();
            NbtCompound entries = nbt.getCompound("origins");
            for (String key : entries.getKeys()) {
                try {
                    String origin = entries.getString(key);
                    if (originIndex(origin) >= 0) state.origins.put(UUID.fromString(key), origin);
                } catch (IllegalArgumentException ignored) {
                    LOGGER.warn("Skipping invalid Origin entry: {}", key);
                }
            }
            return state;
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, net.minecraft.registry.RegistryWrapper.WrapperLookup registries) {
            NbtCompound entries = new NbtCompound();
            for (Map.Entry<UUID, String> entry : origins.entrySet()) {
                entries.putString(entry.getKey().toString(), entry.getValue());
            }
            nbt.put("origins", entries);
            return nbt;
        }
    }
}
