# ECLIPSE SMP Origins (ridwanmod)

Fabric mod project targeting Minecraft Java 1.21.11 and Java 21.

## Features implemented in source

- Four selectable Origins: VOLT, SHADE, VERDANT, EMBER.
- One passive trait per Origin.
- Four active powers per Origin (16 total), activated with `/power 1` through `/power 4`.
- `/origin`, `/origin list`, `/origin info`, `/origin choose <origin>`.
- Operator-only `/origin set <player> <origin>` and `/origin reset <player>`.
- Origin choices are stored in the Overworld persistent state.
- Server-side power execution and per-player/per-power cooldowns.
- Player-vs-player damage respects the server `pvp` gamerule.
- Dash/blink movement checks for free space and powers avoid intentional block destruction.

## Commands

- `/origin list` — list Origins.
- `/origin` — show your selected Origin.
- `/origin info` — show passive and active powers.
- `/origin choose volt|shade|verdant|ember` — choose once.
- `/power info` — list your four powers and cooldowns.
- `/power 1` through `/power 4` — use a power.
- `/origin set <player> <origin>` — operator command to assign an Origin.
- `/origin reset <player>` — operator command to clear an Origin.

## Powers

| Origin | Passive | Power 1 | Power 2 | Power 3 | Power 4 |
|---|---|---|---|---|---|
| VOLT | +15% movement speed | Thunder Dash | Lightning Strike | Super Jump | Electric Shock |
| SHADE | +5% movement speed and slow-fall protection | Shadow Blink | Veil of Shadows | Shadow Decoy | Darkness Wave |
| VERDANT | +2 hearts maximum health | Nature Heal | Vine Trap | Thorn Strike | Nature Shield |
| EMBER | Fire resistance | Fireball | Inferno Burst | Flame Dash | Fire Shield |

**Shadow Decoy note:** this implementation uses a short-lived smoke/portal particle distraction and a brief speed boost as a lightweight alternative to spawning a true skin-copying clone. Fireball is implemented as a small fireball projectile. The effects are deliberately bounded for a small survival SMP.

## Build

Requires an internet connection the first time Gradle downloads its distribution and dependencies.

1. Install JDK 21.
2. Open this project in a Gradle-capable environment, or run `./gradlew build` on Linux/macOS (`gradlew.bat build` on Windows).
3. The remapped mod JAR should be created under `build/libs/`.

## Important test status

The source was authored against the project's configured Minecraft 1.21.11 / Yarn / Fabric versions. A build could **not** be run in this environment because the Gradle wrapper could not download Gradle from `services.gradle.org` (network DNS unavailable). Therefore compilation and in-game behavior remain **untested** here; build and test on an internet-connected Java 21 environment before installing on the SMP server.
